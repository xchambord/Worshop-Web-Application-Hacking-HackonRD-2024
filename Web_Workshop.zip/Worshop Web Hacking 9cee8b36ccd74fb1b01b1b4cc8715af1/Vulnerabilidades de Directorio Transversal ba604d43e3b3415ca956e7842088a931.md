# Vulnerabilidades de Directorio Transversal

¿Qué es el Path Traversal?

Path Traversal o Directory Traversal en inglés, es una vulnerabilidad de seguridad que ocurre cuando una aplicación web permite a un usuario acceder a archivos o directorios fuera del directorio permitido. Este tipo de vulnerabilidad ocurre cuando la aplicación no valida adecuadamente las entradas del usuario que especifican la ubicación de un archivo.

Por ejemplo, si una aplicación web permite a los usuarios ver archivos en un directorio determinado utilizando una URL como "*http://example.com/viewfile?file=archivo.txt*", un atacante podría intentar manipular el parámetro "*file*" para acceder a archivos fuera del directorio permitido. Por ejemplo, podrían probar con "*../etc/passwd*" para intentar acceder al archivo de contraseñas del sistema.

Los ataques de path traversal pueden ser peligrosos, ya que podrían permitir a un atacante acceder a archivos confidenciales del sistema, como archivos de configuración, contraseñas o incluso ejecutables sensibles. Esto podría llevar a una escalada de privilegios o al robo de información sensible.

## Lectura de archivos arbitrarios mediante Path Traversal

Imagine una aplicación de compras que muestra imágenes de artículos a la venta. Esto podría cargar una imagen usando el siguiente HTML:

```html
<img src="/loadImage?filename=218.png">
```

La URL *loadImage* toma un parámetro de *filename* y devuelve el contenido del archivo especificado. Los archivos de imagen se almacenan en el disco en la ubicación */var/www/images/*. Para devolver una imagen, la aplicación agrega el nombre de archivo solicitado a este directorio base y utiliza una API del sistema de archivos para leer el contenido del archivo. En otras palabras, la aplicación lee la siguiente ruta de archivo:

```html
/var/www/images/218.png
```

Esta aplicación no implementa defensas contra ataques de recorrido de ruta. Como resultado, un atacante puede solicitar la siguiente URL para recuperar el archivo */etc/passwd* del sistema de archivos del servidor:

```html
[https://insecure-website.com/loadImage?filename=../../../etc/passwd](https://insecure-website.com/loadImage?filename=../../../etc/passwd)
```

Esto hace que la aplicación lea desde la siguiente ruta de archivo:

```html
/var/www/images/../../../etc/passwd
```

La secuencia *../* es válida dentro de una ruta de archivo y significa subir un nivel en la estructura del directorio. Las tres secuencias *../* consecutivas avanzan desde */var/www/images/* hasta la raíz del sistema de archivos, por lo que el archivo que realmente se lee es:

```html
/etc/passwd
```

En los sistemas operativos basados en Unix, este es un archivo estándar que contiene detalles de los usuarios registrados en el servidor, pero un atacante podría recuperar otros archivos arbitrarios utilizando la misma técnica.

En Windows, tanto ../ como ..\ son secuencias válidas de recorrido de directorio. El siguiente es un ejemplo de un ataque equivalente contra un servidor basado en Windows:

```html
[https://insecure-website.com/loadImage?filename=](https://insecure-website.com/loadImage?filename=)..\..\..\windows\win.ini
```

[Ejemplo](Vulnerabilidades%20de%20Directorio%20Transversal%20ba604d43e3b3415ca956e7842088a931/Ejemplo%20e054d99c6e4249c0b769ef3c2ba240ad.md)

# Cómo prevenir un ataque de recorrido de ruta

La forma más eficaz de evitar vulnerabilidades de recorrido de ruta es evitar por completo pasar la entrada proporcionada por el usuario a las API del sistema de archivos. Muchas funciones de aplicaciones que hacen esto se pueden reescribir para ofrecer el mismo comportamiento de una manera más segura.

Si no puede evitar pasar información proporcionada por el usuario a las API del sistema de archivos, le recomendamos utilizar dos capas de defensa para evitar ataques:

- Valide la entrada del usuario antes de procesarla. Lo ideal es comparar la entrada del usuario con una lista blanca de valores permitidos. Si eso no es posible, verifique que la entrada contenga solo contenido permitido, como caracteres alfanuméricos únicamente.
- Después de validar la entrada proporcionada, agregue la entrada al directorio base y use una API del sistema de archivos de la plataforma para canonicalizar la ruta. Verifique que la ruta canonicalizada comience con el directorio base esperado.

A continuación se muestra un ejemplo de código Java simple para validar la ruta canónica de un archivo según la entrada del usuario:

```java
File file = new File(BASE_DIRECTORY, userInput);
if (file.getCanonicalPath().startsWith(BASE_DIRECTORY)) {
// process file
}
```