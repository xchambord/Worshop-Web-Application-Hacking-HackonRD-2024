# Vulnerabilidad en la carga de Archivo

## ¿Cuáles son las vulnerabilidades de carga de archivos?

Las vulnerabilidades de carga de archivos ocurren cuando un servidor web permite a los usuarios cargar archivos en su sistema de archivos sin validar suficientemente elementos como su nombre, tipo, contenido o tamaño. No aplicar adecuadamente las restricciones sobre estos podría significar que incluso una función básica de carga de imágenes pueda usarse para cargar archivos arbitrarios y potencialmente peligrosos. Esto podría incluso incluir archivos de script del lado del servidor que permitan la ejecución remota de código.

En algunos casos, el hecho de cargar el archivo es por sí solo suficiente para causar daños. Otros ataques pueden implicar una solicitud HTTP de seguimiento del archivo, normalmente para activar su ejecución por parte del servidor.

## ¿Cuál es el impacto de las vulnerabilidades de carga de archivos?

El impacto de las vulnerabilidades de carga de archivos generalmente depende de dos factores clave:

- Qué aspecto del archivo el sitio web no valida correctamente, ya sea su tamaño, tipo, contenido, etc.
- Qué restricciones se imponen al archivo una vez que se ha cargado correctamente.

En el peor de los casos, el tipo de archivo no se valida correctamente y la configuración del servidor permite que ciertos tipos de archivos (como .php y .jsp) se ejecuten como código. En este caso, un atacante podría cargar un archivo de código del lado del servidor que funcione como un shell web, otorgándole efectivamente control total sobre el servidor.

Si el nombre del archivo no se valida correctamente, esto podría permitir que un atacante sobrescriba archivos críticos simplemente cargando un archivo con el mismo nombre. Si el servidor también es vulnerable al cruce de directorios, esto podría significar que los atacantes incluso pueden cargar archivos en ubicaciones imprevistas.

No asegurarse de que el tamaño del archivo esté dentro de los umbrales esperados también podría permitir una forma de ataque de denegación de servicio (DoS), mediante el cual el atacante llena el espacio disponible en el disco.

## ¿Cómo surgen las vulnerabilidades en la carga de archivos?

Dados los peligros bastante obvios, es raro que los sitios web no tengan restricciones de ningún tipo sobre los archivos que los usuarios pueden cargar. Más comúnmente, los desarrolladores implementan lo que creen que es una validación sólida que es inherentemente defectuosa o puede ser fácilmente eludida.

Por ejemplo, pueden intentar incluir en la lista negra tipos de archivos peligrosos, pero no tienen en cuenta las discrepancias en el análisis al verificar las extensiones de los archivos. Al igual que con cualquier lista negra, también es fácil omitir accidentalmente tipos de archivos más oscuros que aún pueden ser peligrosos.

En otros casos, el sitio web puede intentar comprobar el tipo de archivo verificando propiedades que un atacante pueda manipular fácilmente utilizando herramientas como Burp Proxy o Repetidor.

En última instancia, incluso medidas de validación sólidas pueden aplicarse de manera inconsistente en toda la red de hosts y directorios que forman el sitio web, lo que genera discrepancias que pueden explotarse.

## ¿Cómo manejan los servidores web las solicitudes de archivos estáticos?

Antes de ver cómo explotar las vulnerabilidades de carga de archivos, es importante que tenga un conocimiento básico de cómo los servidores manejan las solicitudes de archivos estáticos.

Históricamente, los sitios web consistían casi en su totalidad en archivos estáticos que se entregaban a los usuarios cuando los solicitaban. Como resultado, la ruta de cada solicitud se podría asignar 1:1 con la jerarquía de directorios y archivos en el sistema de archivos del servidor. Hoy en día, los sitios web son cada vez más dinámicos y la ruta de una solicitud a menudo no tiene ninguna relación directa con el sistema de archivos. Sin embargo, los servidores web todavía procesan solicitudes de algunos archivos estáticos, incluidas hojas de estilo, imágenes, etc.

El proceso para manejar estos archivos estáticos sigue siendo prácticamente el mismo. En algún momento, el servidor analiza la ruta en la solicitud para identificar la extensión del archivo. Luego usa esto para determinar el tipo de archivo que se solicita, generalmente comparándolo con una lista de asignaciones preconfiguradas entre extensiones y tipos MIME. Lo que sucede a continuación depende del tipo de archivo y de la configuración del servidor.

- Si este tipo de archivo no es ejecutable, como una imagen o una página HTML estática, el servidor puede simplemente enviar el contenido del archivo al cliente en una respuesta HTTP.
- Si el tipo de archivo es ejecutable, como un archivo PHP, y el servidor está configurado para ejecutar archivos de este tipo, asignará variables según los encabezados y parámetros de la solicitud HTTP antes de ejecutar el script. El resultado resultante se puede enviar al cliente en una respuesta HTTP.
- Si el tipo de archivo es ejecutable, pero el servidor no está configurado para ejecutar archivos de este tipo, generalmente responderá con un error. Sin embargo, en algunos casos, es posible que el contenido del archivo aún se entregue al cliente como texto sin formato. En ocasiones, estas configuraciones erróneas pueden aprovecharse para filtrar el código fuente y otra información confidencial. Puede ver un ejemplo de esto en nuestros materiales de aprendizaje sobre divulgación de información.

## Explotar la carga de archivos sin restricciones para implementar un shell web

Desde una perspectiva de seguridad, el peor escenario posible es cuando un sitio web le permite cargar scripts del lado del servidor, como archivos PHP, Java o Python, y también está configurado para ejecutarlos como código. Esto hace que sea trivial crear su propio shell web en el servidor.

> Web Shell
> 

> Un web shell es un script malicioso que permite a un atacante ejecutar comandos arbitrarios en un servidor web remoto simplemente enviando solicitudes HTTP al punto final correcto.
> 

Si puede cargar con éxito un shell web, efectivamente tendrá control total sobre el servidor. Esto significa que puede leer y escribir archivos arbitrarios, filtrar datos confidenciales e incluso usar el servidor para realizar ataques tanto contra la infraestructura interna como contra otros servidores fuera de la red. Por ejemplo, el siguiente resumen PHP podría usarse para leer archivos arbitrarios del sistema de archivos del servidor:

```php
<?php echo file_get_contents('/path/to/target/file'); ?>
```

Una vez cargado, enviar una solicitud para este archivo malicioso devolverá el contenido del archivo de destino en la respuesta.

[Ejemplo](Vulnerabilidad%20en%20la%20carga%20de%20Archivo%20f6568ae2914a4698bfa732f89cf5ed50/Ejemplo%20aad338a44d2c4ca68241480d101ca5f3.md)

Un shell web más versátil podría verse así:

```php
<?php echo system($_GET['command']); ?>
```

Este script le permite pasar un comando del sistema arbitrario a través de un parámetro de consulta de la siguiente manera:

```php
GET /example/exploit.php?command=id HTTP/1.1
```

## Ofuscar extensiones de archivos

Incluso las listas negras más exhaustivas pueden evitarse utilizando técnicas de ofuscación clásicas. Digamos que el código de validación distingue entre mayúsculas y minúsculas y no reconoce que exploit.pHp es en realidad un archivo .php. Si el código que posteriormente asigna la extensión del archivo a un tipo MIME no distingue entre mayúsculas y minúsculas, esta discrepancia le permite pasar la validación de archivos PHP maliciosos que eventualmente pueden ser ejecutados por el servidor.

También puede lograr resultados similares utilizando las siguientes técnicas:

- Proporcionar múltiples extensiones. Dependiendo del algoritmo utilizado para analizar el nombre del archivo, el siguiente archivo puede interpretarse como un archivo PHP o una imagen JPG: exploit.php.jpg
- Añade caracteres finales. Algunos componentes eliminarán o ignorarán los espacios en blanco finales, puntos y cosas similares: exploit.php.
Intente utilizar la codificación de URL (o codificación de URL doble) para puntos, barras diagonales y barras diagonales invertidas. Si el valor no se decodifica al validar la extensión del archivo, pero luego se decodifica en el lado del servidor, esto también puede permitirle cargar archivos maliciosos que de otro modo serían bloqueados: exploit%2Ephp
- Agregue punto y coma o caracteres de bytes nulos codificados en URL antes de la extensión del archivo. Si la validación está escrita en un lenguaje de alto nivel como PHP o Java, pero el servidor procesa el archivo usando funciones de nivel inferior en C/C++, por ejemplo, esto puede causar discrepancias en lo que se trata como el final del nombre del archivo: exploit .asp;.jpg o explotar.asp%00.jpg
- Intente utilizar caracteres Unicode multibyte, que pueden convertirse en bytes y puntos nulos después de la conversión o normalización Unicode. Secuencias como xC0 x2E, xC4 xAE o xC0 xAE pueden traducirse a x2E si el nombre del archivo se analiza como una cadena UTF-8, pero luego se convierte a caracteres ASCII antes de usarse en una ruta.

Otras defensas implican eliminar o reemplazar extensiones peligrosas para evitar que se ejecute el archivo. Si esta transformación no se aplica de forma recursiva, puede colocar la cadena prohibida de tal manera que al eliminarla aún quede una extensión de archivo válida. Por ejemplo, considere lo que sucede si elimina .php del siguiente nombre de archivo:

```php
exploit.p.phphp
```

Esta es sólo una pequeña selección de las muchas formas en que es posible ofuscar las extensiones de archivos.

[Ejemplo](Vulnerabilidad%20en%20la%20carga%20de%20Archivo%20f6568ae2914a4698bfa732f89cf5ed50/Ejemplo%2043927b264a3c4b21bada33d730c02e51.md)

## Cómo prevenir vulnerabilidades en la carga de archivos

Permitir a los usuarios cargar archivos es algo común y no tiene por qué ser peligroso siempre que se tomen las precauciones adecuadas. En general, la forma más eficaz de proteger sus propios sitios web de estas vulnerabilidades es implementar todas las prácticas siguientes:

- Verifique la extensión del archivo con una lista blanca de extensiones permitidas en lugar de una lista negra de extensiones prohibidas. Es mucho más fácil adivinar qué extensiones es posible que desee permitir que adivinar cuáles podría intentar cargar un atacante.
- Asegúrese de que el nombre del archivo no contenga ninguna subcadena que pueda interpretarse como un directorio o una secuencia transversal (../).
- Cambie el nombre de los archivos cargados para evitar colisiones que puedan provocar que se sobrescriban los archivos existentes.
- No cargue archivos al sistema de archivos permanente del servidor hasta que hayan sido completamente validados.
- En la medida de lo posible, utilice un marco establecido para preprocesar la carga de archivos en lugar de intentar escribir sus propios mecanismos de validación.