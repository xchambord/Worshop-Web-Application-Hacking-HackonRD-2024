# Hacking en autenticación Web (Login)

## ¿Qué es una autenticación?

La autenticación es el proceso mediante el cual se verifica la identidad de un usuario o entidad que solicita acceso a un sistema, servicio o recurso. Este proceso se lleva a cabo mediante la presentación de credenciales (como nombres de usuario y contraseñas, tarjetas de identificación, tokens, etc.) que se comparan con información previamente almacenada y autorizada en el sistema.

El objetivo principal de la autenticación es asegurar que la persona o entidad que intenta acceder a un sistema realmente sea quien dice ser. Este proceso es fundamental para garantizar la seguridad y la integridad de los sistemas informáticos y los datos que contienen.

## Tipos de autenticación.

Los Tipos de autenticación pueden variar dependiendo del contexto y de los requisitos de seguridad del sistema en cuestión. Algunos de los Tipos comunes de autenticación incluyen:

1. **Autenticación basada en conocimiento (algo que el usuario sabe)**: Este tipo implica que el usuario proporciona información que solo él o ella debe conocer, como contraseñas, respuestas a preguntas de seguridad, o patrones de entrada (como gestos en dispositivos táctiles).
2. **Autenticación basada en posesión (algo que el usuario tiene)**: En este tipo, el usuario debe poseer un objeto físico o electrónico para demostrar su identidad. Ejemplos incluyen tarjetas de identificación, tokens de seguridad, llaves físicas o dispositivos móviles que generan códigos de acceso únicos.
3. **Autenticación basada en inherencia (algo que el usuario es)**: Este tipo de autenticación utiliza características biológicas o de comportamiento únicas del usuario para verificar su identidad, como reconocimiento facial, huellas dactilares, iris o voz.

Además de estos métodos, también existen sistemas de autenticación más avanzados que combinan múltiples factores (conocimiento, posesión, inherencia) para aumentar la seguridad, lo que se conoce como autenticación multifactorial o de dos factores (2FA).

## Diferencia entre Autenticación y Autorización

La autenticación y la autorización son dos conceptos relacionados pero distintos en el ámbito del Hacking en aplicaciones web:

1. **Autenticación**:
    - **Definición**: La autenticación es el proceso mediante el cual se verifica la identidad de un usuario o entidad que solicita acceso a un sistema, servicio o recurso.
    - **Objetivo**: La autenticación garantiza que la persona o entidad que intenta acceder a un sistema sea quien dice ser.
    - **Ejemplo**: Cuando un usuario ingresa su nombre de usuario y contraseña para iniciar sesión en un sitio web, el sistema verifica estas credenciales para determinar si corresponden a una cuenta válida en su base de datos.
2. **Autorización**:
    - **Definición**: La autorización es el proceso mediante el cual se determina si un usuario autenticado tiene permiso para acceder a recursos específicos o realizar determinadas acciones dentro de un sistema.
    - **Objetivo**: La autorización define qué recursos o acciones puede acceder o realizar un usuario autenticado.
    - **Ejemplo**: Después de que un usuario se autentica correctamente en un sistema, la autorización determina si tiene permiso para ver, modificar o eliminar ciertos archivos, carpetas o datos dentro del sistema.
    
    En resumen, mientras que la autenticación se centra en verificar la identidad del usuario, la autorización se centra en determinar qué acciones o recursos tiene permitido acceder ese usuario una vez que su identidad ha sido confirmada.
    
    ## Origen de la vulnerabilidad.
    
    Las vulnerabilidades de autenticación pueden surgir debido a una variedad de factores y errores en el diseño, implementación o configuración de sistemas y aplicaciones. Algunas de las causas comunes de estas vulnerabilidades incluyen:
    
    1. **Falta de políticas de contraseña**: La ausencia de políticas de contraseña claras y estrictas puede llevar a que los usuarios elijan contraseñas débiles o fácilmente predecibles, lo que aumenta el riesgo de que sean comprometidas.
    2. **Vulnerabilidades en la interfaz de autenticación**: Fallos en el diseño o la implementación de la interfaz de autenticación, como la omisión de controles de seguridad adecuados o la exposición de información sensible en mensajes de error, pueden facilitar ataques de suplantación de identidad o manipulación de credenciales.
    3. **Falta de protección contra ataques de fuerza bruta**: La ausencia de medidas para prevenir o mitigar ataques de fuerza bruta o ataques de diccionario puede permitir a los atacantes probar múltiples combinaciones de nombres de usuario y contraseñas hasta encontrar una que funcione.
    4. **Funcionalidades de autenticación inseguras**: Implementar funcionalidades de autenticación como la recuperación de contraseñas o el cambio de credenciales de manera insegura puede abrir la puerta a ataques de suplantación de identidad o de redefinición de contraseñas.
    
    ## Vulnerabilidades en los mecanismos de autenticación
    
    El sistema de autenticación de un sitio web generalmente consta de varios mecanismos distintos en los que pueden ocurrir vulnerabilidades. Algunas vulnerabilidades son aplicables en todos estos contextos. Otros son más específicos de la funcionalidad proporcionada.
    
    ### Los tres mecanismos mas comunes a analizar son los siguientes:
    
    [Vulnerabilidades de inicio de sesión basado en contraseña](Hacking%20en%20autenticacio%CC%81n%20Web%20(Login)%20aa59dd50e2a9447a94e29707d63444e2/Vulnerabilidades%20de%20inicio%20de%20sesio%CC%81n%20basado%20en%20co%20dd2d581223c04312980a6f4406725ffa.md)
    
    [Vulnerabilidades de autenticación multifactor](Hacking%20en%20autenticacio%CC%81n%20Web%20(Login)%20aa59dd50e2a9447a94e29707d63444e2/Vulnerabilidades%20de%20autenticacio%CC%81n%20multifactor%20ea9f8fa99f964aed9baecb334f5b0e85.md)
    
    [Vulnerabilidades en otros mecanismos de autenticación](Hacking%20en%20autenticacio%CC%81n%20Web%20(Login)%20aa59dd50e2a9447a94e29707d63444e2/Vulnerabilidades%20en%20otros%20mecanismos%20de%20autenticac%202cc636ab728c445093cddd24fe6ff0e5.md)
    
    ## Cómo proteger sus mecanismos de autenticación
    
    La autenticación es un tema complejo y, como hemos demostrado, desafortunadamente es muy fácil que surjan debilidades y fallas. Claramente no es posible describir todas las medidas posibles que puede tomar para proteger sus propios sitios web. Sin embargo, existen varios principios generales que siempre debes seguir.
    
    ### Cuidado con las credenciales de usuario
    
    Incluso los mecanismos de autenticación más sólidos son ineficaces si, sin saberlo, revela un conjunto válido de credenciales de inicio de sesión a un atacante. No hace falta decir que nunca debes enviar datos de inicio de sesión a través de conexiones no cifradas. Aunque es posible que haya implementado HTTPS para sus solicitudes de inicio de sesión, asegúrese de aplicarlo redirigiendo también cualquier intento de solicitud HTTP a HTTPS.
    
    También debe auditar su sitio web para asegurarse de que ningún nombre de usuario o dirección de correo electrónico se divulgue a través de perfiles de acceso público ni se refleje en respuestas HTTP, por ejemplo.
    
    ### No cuente con los usuarios por seguridad
    
    Las medidas de autenticación estrictas a menudo requieren un esfuerzo adicional por parte de los usuarios. La naturaleza humana hace que sea casi inevitable que algunos usuarios encuentren formas de ahorrarse este esfuerzo. Por lo tanto, es necesario imponer un comportamiento seguro siempre que sea posible.
    
    El ejemplo más obvio es implementar una política de contraseñas eficaz. Algunas de las políticas más tradicionales fracasan porque las personas introducen sus propias contraseñas predecibles en la política. En cambio, puede ser más efectivo implementar un verificador de contraseñas simple de algún tipo, que permita a los usuarios experimentar con contraseñas y proporcione retroalimentación sobre su solidez en tiempo real. Un ejemplo popular es la biblioteca JavaScript zxcvbn, desarrollada por Dropbox. Al permitir únicamente contraseñas que tengan una calificación alta según el verificador de contraseñas, puede imponer el uso de contraseñas seguras de manera más efectiva que con las políticas tradicionales.
    
    ### Evitar la enumeración de nombres de usuario
    
    Es considerablemente más fácil para un atacante romper sus mecanismos de autenticación si revela que existe un usuario en el sistema. Incluso hay determinadas situaciones en las que, debido a la naturaleza del sitio web, el conocimiento de que una persona concreta tiene una cuenta es información sensible en sí misma.
    
    Independientemente de si un intento de nombre de usuario es válido, es importante utilizar mensajes de error genéricos idénticos y asegurarse de que realmente sean idénticos. Siempre debes devolver el mismo código de estado HTTP con cada solicitud de inicio de sesión y, finalmente, hacer que los tiempos de respuesta en diferentes escenarios sean lo más indistinguibles posible.
    
    ### Implementar una sólida protección contra la fuerza bruta
    
    Dado lo simple que puede ser construir un ataque de fuerza bruta, es vital asegurarse de tomar medidas para prevenir, o al menos interrumpir, cualquier intento de inicio de sesión por fuerza bruta.
    
    Uno de los métodos más eficaces es implementar una limitación estricta de la tasa de usuarios basada en IP. Esto debería implicar medidas para evitar que los atacantes manipulen su dirección IP aparente. Idealmente, debería solicitar al usuario que complete una prueba CAPTCHA con cada intento de inicio de sesión después de alcanzar un cierto límite.
    
    Tenga en cuenta que no se garantiza que esto elimine por completo la amenaza de la fuerza bruta. Sin embargo, hacer que el proceso sea lo más tedioso y manual posible aumenta la probabilidad de que cualquier posible atacante se dé por vencido y busque un objetivo más fácil.
    
    ### Verifique tres veces su lógica de verificación
    
    Como lo demostraron nuestros laboratorios, es fácil que se introduzcan fallas lógicas simples en el código que, en el caso de la autenticación, tienen el potencial de comprometer completamente su sitio web y a sus usuarios. Auditar minuciosamente cualquier lógica de verificación o validación para eliminar fallas es absolutamente clave para una autenticación sólida. Un control que se puede eludir no es, en última instancia, mucho mejor que ningún control.
    
    ### No olvides la funcionalidad complementaria
    
    Asegúrese de no centrarse únicamente en las páginas de inicio de sesión centrales y pasar por alto funciones adicionales relacionadas con la autenticación. Esto es particularmente importante en los casos en que el atacante es libre de registrar su propia cuenta y explorar esta funcionalidad. Recuerde que restablecer o cambiar una contraseña es una superficie de ataque tan válida como el mecanismo de inicio de sesión principal y, en consecuencia, debe ser igualmente sólido.
    
    ### Implementar una autenticación multifactor adecuada
    
    Si bien la autenticación multifactor puede no ser práctica para todos los sitios web, cuando se realiza correctamente es mucho más segura que el inicio de sesión basado únicamente en una contraseña. Recuerde que verificar varias instancias del mismo factor no es una verdadera autenticación multifactor. Enviar códigos de verificación por correo electrónico es esencialmente una forma más extensa de autenticación de un solo factor.
    
    La 2FA basada en SMS técnicamente verifica dos factores (algo que sabes y algo que tienes). Sin embargo, la posibilidad de que se produzcan abusos mediante el intercambio de SIM, por ejemplo, significa que este sistema puede resultar poco fiable.
    
    Idealmente, la 2FA debería implementarse utilizando un dispositivo o aplicación dedicada que genere el código de verificación directamente. Como están diseñados específicamente para brindar seguridad, suelen ser más seguros.
    
    Finalmente, al igual que con la lógica de autenticación principal, asegúrese de que la lógica en sus comprobaciones 2FA sea sólida para que no pueda omitirse fácilmente.