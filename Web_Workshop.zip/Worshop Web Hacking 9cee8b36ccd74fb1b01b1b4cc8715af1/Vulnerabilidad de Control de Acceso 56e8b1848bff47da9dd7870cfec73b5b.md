# Vulnerabilidad de Control de Acceso

## ¿Qué es el control de acceso?

El control de acceso es la aplicación de restricciones sobre quién o qué está autorizado a realizar acciones o acceder a recursos. En el contexto de las aplicaciones web, el control de acceso depende de la autenticación y la gestión de sesiones:

- La autenticación confirma que el usuario es quien dice ser.
- La gestión de sesiones identifica qué solicitudes HTTP posteriores realiza ese mismo usuario.
- El control de acceso determina si el usuario puede realizar la acción que intenta realizar.

Los controles de acceso rotos son comunes y a menudo presentan una vulnerabilidad de seguridad crítica. El diseño y la gestión de controles de acceso es un problema complejo y dinámico que aplica restricciones comerciales, organizativas y legales a una implementación técnica. Las decisiones de diseño del control de acceso deben ser tomadas por humanos, por lo que el potencial de errores es alto.

## Controles de acceso verticales

Los controles de acceso vertical son mecanismos que restringen el acceso a funciones confidenciales a tipos específicos de usuarios.

Con los controles de acceso vertical, diferentes tipos de usuarios tienen acceso a diferentes funciones de la aplicación. Por ejemplo, un administrador podría modificar o eliminar la cuenta de cualquier usuario, mientras que un usuario normal no tiene acceso a estas acciones. Los controles de acceso vertical pueden ser implementaciones más detalladas de modelos de seguridad diseñados para hacer cumplir políticas comerciales como la separación de funciones y privilegios mínimos.

## Controles de acceso horizontales

Horizontal access controls are mechanisms that restrict access to resources to specific users.

Con controles de acceso horizontal, diferentes usuarios tienen acceso a un subconjunto de recursos del mismo tipo. Por ejemplo, una aplicación bancaria permitirá a un usuario ver transacciones y realizar pagos desde sus propias cuentas, pero no desde las cuentas de ningún otro usuario.

# Ejemplos de controles de acceso rotos

Las vulnerabilidades de control de acceso roto existen cuando un usuario puede acceder a recursos o realizar acciones que se supone que no debería poder realizar.

## Escalada de privilegios verticales

Si un usuario puede obtener acceso a una funcionalidad a la que no tiene permiso, se trata de una escalada de privilegios vertical. Por ejemplo, si un usuario no administrativo puede obtener acceso a una página de administración donde puede eliminar cuentas de usuario, entonces se trata de una escalada de privilegios vertical.

### Funcionalidad desprotegida

En su forma más básica, la escalada de privilegios verticales surge cuando una aplicación no aplica ninguna protección para funciones confidenciales. Por ejemplo, las funciones administrativas pueden estar vinculadas desde la página de bienvenida de un administrador pero no desde la página de bienvenida de un usuario. Sin embargo, un usuario podría acceder a las funciones administrativas navegando a la URL de administrador correspondiente.

Por ejemplo, un sitio web puede alojar funciones confidenciales en la siguiente URL:

```jsx
[https://insecure-website.com/admin](https://insecure-website.com/admin)
```

Cualquier usuario puede acceder a esto, no solo los usuarios administrativos que tienen un enlace a la funcionalidad en su interfaz de usuario. En algunos casos, la URL administrativa puede revelarse en otras ubicaciones, como en el archivo robots.txt:

```jsx
[https://insecure-website.com/robots.txt](https://insecure-website.com/robots.txt)
```

Incluso si la URL no se divulga en ninguna parte, un atacante puede usar una lista de palabras para forzar la ubicación de la funcionalidad confidencial.

[Ejemplo](Vulnerabilidad%20de%20Control%20de%20Acceso%2056e8b1848bff47da9dd7870cfec73b5b/Ejemplo%200ea01cf360874010b9c89cbfcf8d1074.md)

## Escalada de privilegios horizontales

La escalada de privilegios horizontal se produce si un usuario puede obtener acceso a recursos que pertenecen a otro usuario, en lugar de a sus propios recursos de ese tipo. Por ejemplo, si un empleado puede acceder a los registros de otros empleados además de a los suyos propios, entonces se trata de una escalada de privilegios horizontal.

Los ataques de escalada de privilegios horizontales pueden utilizar tipos de métodos de explotación similares a los de la escalada de privilegios vertical. Por ejemplo, un usuario podría acceder a la página de su propia cuenta utilizando la siguiente URL:

```jsx
[https://insecure-website.com/myaccount?id=123](https://insecure-website.com/myaccount?id=123)
```

Si un atacante modifica el valor del parámetro id por el de otro usuario, podría obtener acceso a la página de la cuenta de otro usuario y a los datos y funciones asociados.

[Ejemplo](Vulnerabilidad%20de%20Control%20de%20Acceso%2056e8b1848bff47da9dd7870cfec73b5b/Ejemplo%20354b4c398b0e4fd28bcb61d25302c880.md)

# Cómo prevenir vulnerabilidades en el control de acceso

Las vulnerabilidades del control de acceso se pueden prevenir adoptando un enfoque de defensa en profundidad y aplicando los siguientes principios:

- Nunca confíe únicamente en la ofuscación para el control de acceso.
- A menos que un recurso esté destinado a ser accesible públicamente, deniegue el acceso de forma predeterminada.
- Siempre que sea posible, utilice un único mecanismo para toda la aplicación para hacer cumplir los controles de acceso.
- A nivel de código, haga obligatorio que los desarrolladores declaren el acceso permitido para cada recurso y deniegue el acceso de forma predeterminada.
- Audite y pruebe minuciosamente los controles de acceso para garantizar que funcionen según lo diseñado.