# Reconocimiento en Hacking de aplicaciones Web

El reconocimiento en hacking de aplicaciones web, también conocido como "reconocimiento web", es la primera fase del proceso de prueba de penetración, en la cual el hacker recopila información sobre el objetivo de su ataque. Esta información es crucial para comprender la infraestructura de la aplicación, identificar posibles vulnerabilidades y planificar los siguientes pasos del ataque.

## Enumeraciones Comunes:

### Enumeración de Subdominios

La enumeración de subdominios es una técnica utilizada en hacking ético o pruebas de penetración para identificar todos los subdominios asociados con un dominio principal. Esta actividad es importante para comprender completamente la superficie de ataque de una organización y descubrir posibles puntos de entrada adicionales. 

La enumeración de subdominios tiene varios objetivos en el ámbito de la seguridad informática y el hacking ético. Algunos de los objetivos principales incluyen:

1. **Ampliar la Superficie de Ataque:** Al identificar todos los subdominios asociados con un dominio principal, se amplía la superficie de ataque potencial. Esto permite a los profesionales de seguridad y a los pentesters evaluar de manera más exhaustiva la seguridad de una organización o aplicación web.
2. **Descubrir Puntos de Entrada Adicionales:** Cada subdominio puede representar un posible punto de entrada para un atacante. Al enumerar estos subdominios, se identifican posibles vectores de ataque que podrían haber pasado desapercibidos de otra manera.
3. **Identificar Servicios y Tecnologías Utilizadas:** Los subdominios pueden indicar la presencia de servicios o tecnologías específicas utilizadas por una organización. Esto proporciona información valiosa para los profesionales de seguridad, ya que pueden investigar y evaluar las vulnerabilidades asociadas con estas tecnologías.
4. **Analizar la Arquitectura de la Aplicación:** La estructura de los subdominios puede ofrecer información sobre la arquitectura de la aplicación web de una organización, como la división de funciones o la separación de entornos de desarrollo, pruebas y producción. Esto puede ayudar a comprender mejor cómo están organizados los sistemas y dónde pueden existir vulnerabilidades.

[Ejemplos](Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea/Ejemplos%20c4bfcb53e8464c068d60c5ccbf05ad0d.md)

### Enumeración de Directorios

La enumeración de directorios es un proceso mediante el cual un atacante intenta descubrir y listar los directorios y archivos accesibles en un servidor web. Este es un paso común en la fase de reconocimiento de un ataque web, donde el objetivo es recopilar información sobre la estructura y contenido del sitio web para identificar posibles puntos de entrada, vulnerabilidades o información sensible.

Los objetivos principales de la enumeración de directorios en hacking de aplicaciones web son:

1. **Reconocimiento del sistema**: Obtener información sobre la estructura del sistema de archivos del servidor web, incluyendo directorios, archivos y permisos asociados.
2. **Identificación de puntos de entrada potenciales**: Descubrir áreas del sitio web que podrían ser vulnerables a ataques, como directorios con permisos de escritura o archivos con información sensible.
3. **Recolección de información sensible**: Encontrar archivos o directorios que contengan información confidencial o sensible, como archivos de configuración, archivos de registro, o incluso credenciales de usuario que podrían haber sido expuestas accidentalmente.
4. **Descubrimiento de recursos ocultos**: Identificar recursos que no están enlazados directamente desde el sitio web pero que aún son accesibles a través de la URL, lo que podría revelar funcionalidades ocultas o áreas no autorizadas.
5. **Preparación para ataques posteriores**: La enumeración de directorios puede proporcionar a un atacante una visión general del sitio web y sus posibles vulnerabilidades, lo que le permite planificar y ejecutar ataques más avanzados, como ataques de fuerza bruta, inyección de SQL o explotación de vulnerabilidades conocidas.

[Ejemplos](Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea/Ejemplos%202a4bdcae1334493bb6aa5fba7d6e9cc0.md)

Enumerar IP detrás de WAF

Enumeracion de Comentarios

Enumeracion de Enlaces internos