# Vulnerabilidades de autenticación multifactor

Podemos ver que muchos sitios web dependen exclusivamente de la autenticación de un solo factor mediante una contraseña para autenticar a los usuarios. Sin embargo, algunos requieren que los usuarios demuestren su identidad mediante múltiples factores de autenticación.

Verificar los factores biométricos no es práctico para la mayoría de los sitios web. Sin embargo, es cada vez más común ver autenticación de dos factores (2FA) obligatoria y opcional basada en algo que sabes y algo que tienes. Por lo general, esto requiere que los usuarios ingresen una contraseña tradicional y un código de verificación temporal desde un dispositivo físico fuera de banda que tengan en su poder.

Si bien a veces es posible que un atacante obtenga un único factor basado en el conocimiento, como una contraseña, es considerablemente menos probable que pueda obtener simultáneamente otro factor de una fuente fuera de banda. Por este motivo, se ha demostrado que la autenticación de dos factores es más segura que la autenticación de un solo factor. Sin embargo, como ocurre con cualquier medida de seguridad, su seguridad sólo es tan segura como su implementación. La autenticación de dos factores mal implementada puede ser superada, o incluso omitida por completo, al igual que la autenticación de un solo factor.

También vale la pena señalar que todos los beneficios de la autenticación multifactor solo se logran verificando múltiples factores diferentes. Verificar el mismo factor de dos maneras diferentes no es una verdadera autenticación de dos factores. La 2FA basada en correo electrónico es un ejemplo de ello. Aunque el usuario debe proporcionar una contraseña y un código de verificación, acceder al código solo depende de que conozca las credenciales de inicio de sesión de su cuenta de correo electrónico. Por lo tanto, el factor de autenticación de conocimientos simplemente se verifica dos veces.

## Tokens de autenticación de dos factores

Los códigos de verificación generalmente los lee el usuario desde un dispositivo físico de algún tipo. Muchos sitios web de alta seguridad ahora brindan a los usuarios un dispositivo dedicado para este propósito, como el token RSA o el dispositivo con teclado que puede usar para acceder a su banca en línea o a su computadora portátil de trabajo. Además de estar diseñados específicamente para la seguridad, estos dispositivos dedicados también tienen la ventaja de generar el código de verificación directamente. También es común que los sitios web utilicen una aplicación móvil dedicada, como Google Authenticator, por el mismo motivo.

Por otro lado, algunos sitios web envían códigos de verificación al teléfono móvil del usuario como mensaje de texto. Si bien técnicamente esto sigue verificando el factor de "algo que tienes", está abierto a abusos. En primer lugar, el código se transmite a través de SMS en lugar de ser generado por el propio dispositivo. Esto crea la posibilidad de que el código sea interceptado. También existe el riesgo de intercambio de SIM, mediante el cual un atacante obtiene de manera fraudulenta una tarjeta SIM con el número de teléfono de la víctima. Luego, el atacante recibiría todos los mensajes SMS enviados a la víctima, incluido el que contiene su código de verificación.

## Bypass a la autenticación de dos factores

En ocasiones, la implementación de la autenticación de dos factores es defectuosa hasta el punto de que se puede omitir por completo.

Si primero se le solicita al usuario que ingrese una contraseña y luego se le solicita que ingrese un código de verificación en una página separada, el usuario se encuentra efectivamente en un estado de "iniciar sesión" antes de ingresar el código de verificación. En este caso, vale la pena probar para ver si puede pasar directamente a las páginas "solo para quienes han iniciado sesión" después de completar el primer paso de autenticación. Ocasionalmente, encontrará que un sitio web en realidad no verifica si completó o no el segundo paso antes de cargar la página.

[Ejemplo](Vulnerabilidades%20de%20autenticacio%CC%81n%20multifactor%20ea9f8fa99f964aed9baecb334f5b0e85/Ejemplo%205589ada5f7b64dc0b034320aa9a6b0d6.md)