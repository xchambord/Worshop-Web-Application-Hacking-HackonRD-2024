# Fundamentos Generales de Hacking a aplicaciones Web

### Que es el Hacking?

Generalmente se define como la práctica de buscar, encontrar y explotar debilidades en sistemas informáticos con el fin de obtener acceso no autorizado, manipular datos o causar daños. Sin embargo, es importante destacar que no todos los actos de hacking son maliciosos, ya que algunos hackers éticos utilizan sus habilidades para identificar vulnerabilidades y mejorar la seguridad de sistemas y redes.

### Que es un Sitio Web?

Un sitio web es un conjunto de páginas web relacionadas y otros recursos digitales, como imágenes, videos, documentos y aplicaciones, que se encuentran alojados en un servidor web y están accesibles a través de Internet. Estas páginas web están diseñadas y organizadas de manera coherente para proporcionar información, recursos o servicios específicos a los usuarios que acceden a ellas.

### Que es un Flujo?

Acción y efecto de fluir. (RAE)

Cuando hablamos de flujo en una aplicacion web, nos referimos a las diferentes acciones que puede un usuario realizar en una pagina web. digase, redactar un comentario, hacer una transferencia, verificar un producto, hacer una compra, etc…

### Tipos de aplicaciones Web

1. Sitios informativos
    1. Un sitio web informativo es una página o conjunto de páginas en Internet diseñadas con el propósito principal de proporcionar información sobre un tema específico. Estos sitios están destinados a educar, informar o entretener a los usuarios, ofreciendo contenido estático o dinámico que aborda diversos temas, desde noticias y eventos hasta tutoriales y reseñas.
    2. Caracteristicas de un sitio Web informativos:
        1. **Contenido Relevante:** Proporciona información útil, precisa y actualizada sobre un tema específico, dirigida a satisfacer las necesidades e intereses de los usuarios.
        2. **Diseño Atractivo y Funcional:** Utiliza un diseño limpio, atractivo y fácil de navegar que resalta el contenido principal y mejora la experiencia del usuario.
        3. **Navegación Intuitiva:** Ofrece menús de navegación claros y etiquetados, enlaces internos relevantes y una arquitectura de sitio coherente para que los usuarios puedan encontrar fácilmente la información que están buscando.
        4. **Multimedia Incorporado:** Utiliza elementos multimedia, como imágenes, gráficos, videos o presentaciones de diapositivas, para mejorar la presentación de la información y hacerla más atractiva y comprensible.
        5. **Actualizaciones Periódicas:** Se actualiza regularmente con nuevo contenido o información actualizada para mantener su relevancia y utilidad para los usuarios a lo largo del tiempo.
    3. A diferencia de los sitios web interactivos o transaccionales, los sitios web informativos suelen tener una interacción limitada con los usuarios, ya que su objetivo principal es proporcionar información estática en lugar de facilitar transacciones o participación activa del usuario.
2. Sitios Transaccionales
    1. Un sitio web transaccional es una plataforma en línea diseñada para facilitar y gestionar transacciones comerciales, financieras o de otro tipo entre los usuarios y el sitio web. A diferencia de los sitios web informativos que principalmente proporcionan contenido estático, los sitios web transaccionales permiten a los usuarios realizar acciones específicas, como comprar productos, realizar reservas, completar formularios, suscribirse a servicios, entre otros, directamente a través del sitio web.
    2. Caracteristicas de un sitio transaccional:
        1. **Funcionalidad de Comercio Electrónico:** El sitio web permite a los usuarios comprar productos o servicios en línea, agregar elementos al carrito de compras, realizar pagos y completar transacciones financieras de manera segura.
        2. **Procesamiento de Pagos:** Integra opciones de pago seguro, como tarjetas de crédito, transferencias bancarias, billeteras electrónicas u otros métodos de pago en línea.
        3. **Formularios Interactivos:** Permite a los usuarios completar formularios en línea para enviar información o realizar solicitudes específicas, como registros de cuentas, solicitudes de información, suscripciones, entre otros.
        4. **Gestión de Cuentas de Usuario:** Proporciona a los usuarios la capacidad de crear y gestionar cuentas personales, donde pueden ver su historial de transacciones, actualizar información personal, gestionar preferencias y más.
        5. **Notificaciones y Confirmaciones:** Envía notificaciones automáticas por correo electrónico o mensajes de texto para confirmar transacciones, actualizar el estado del pedido o proporcionar detalles sobre reservas y citas.
        6. **Integración con Sistemas Externos:** Se integra con otros sistemas externos, como sistemas de gestión de inventario, sistemas de gestión de relaciones con el cliente (CRM) o sistemas de facturación, para sincronizar datos y procesos comerciales.
    
    ### Principales flujos de una aplicación Web
    
    Los flujos de una aplicación o sitio web se refieren a las rutas o caminos que los usuarios siguen mientras interactúan con la plataforma. Estos flujos pueden variar según el propósito y la complejidad del sistema, pero algunos flujos comunes incluyen:
    
    1. **Registro/Inicio de Sesión:**
        - El usuario accede a la página de inicio de sesión o registro.
        - Ingresa sus credenciales o completa el formulario de registro.
        - Se autentica y accede a su cuenta.
    2. **Navegación Principal:**
        - El usuario navega por las diferentes secciones del sitio web o aplicación utilizando el menú de navegación.
        - Accede a las páginas principales, como la página de inicio, la página de productos/servicios, la página de contacto, etc.
    3. **Búsqueda/Exploración:**
        - El usuario utiliza funciones de búsqueda para encontrar información específica, productos o servicios.
        - Explora categorías o filtros para refinar sus resultados.
    4. **Interacción con Contenido:**
        - El usuario lee artículos, ve imágenes, mira videos o escucha audios.
        - Comenta, comparte o reacciona al contenido.
        - Realiza acciones adicionales, como marcar como favorito o guardar contenido para más tarde.
    5. **Carrito de Compras/Selección de Productos:**
        - El usuario selecciona productos y los agrega al carrito de compras.
        - Visualiza y modifica los elementos en el carrito.
        - Procede al proceso de pago.
    6. **Proceso de Pago:**
        - El usuario completa la información de envío y pago.
        - Confirma la compra y realiza el pago.
        - Recibe una confirmación de compra y un recibo.
    7. **Formularios/Registro de Datos:**
        - El usuario completa formularios para enviar información, como información de contacto, detalles de la cuenta, etc.
        - Envía el formulario y recibe una confirmación o mensaje de éxito.
    8. **Interacción Social:**
        - El usuario se conecta con otros usuarios, sigue perfiles, envía mensajes o participa en grupos o comunidades.
    9. **Soporte/Asistencia:**
        - El usuario accede a la sección de ayuda o soporte.
        - Envía una consulta o pregunta a través de un formulario de contacto o chat en vivo.
        - Recibe una respuesta o solución a su problema.
    10. **Cierre de Sesión:**
        - El usuario cierra su sesión o abandona la plataforma.
    11. **Reserva/Programación:**
        - El usuario selecciona un servicio o actividad para reservar.
        - Elige la fecha, hora y otras opciones de reserva.
        - Confirma la reserva y recibe una confirmación por correo electrónico o mensaje de texto.
    12. **Seguimiento de Pedido/Entrega:**
        - El usuario accede a su historial de pedidos o a la sección de seguimiento.
        - Ingresa el número de seguimiento o selecciona un pedido específico.
        - Verifica el estado del pedido y recibe actualizaciones sobre la entrega.
    13. **Configuración de Perfil/Preferencias:**
        - El usuario accede a la configuración de su cuenta o perfil.
        - Actualiza información personal, como nombre, dirección, foto de perfil, etc.
        - Configura preferencias de notificación, privacidad o seguridad.
    14. **Recuperación de Contraseña:**
        - El usuario solicita restablecer su contraseña.
        - Recibe un correo electrónico con un enlace o código para restablecer la contraseña.
        - Crea una nueva contraseña y la confirma.
    15. **Interacción con Servicios de Asistencia:**
        - El usuario accede a la sección de asistencia o ayuda.
        - Selecciona una categoría de problema o pregunta.
        - Chatea con un agente de soporte en vivo o envía un ticket de soporte.
    16. **Exploración de Categorías/Tags:**
        - El usuario navega por categorías o etiquetas de contenido para encontrar temas específicos de interés.
        - Selecciona una categoría o etiqueta y explora los resultados relacionados.
        - Filtra los resultados por relevancia, fecha o popularidad.
    17. **Creación/Edición de Contenido:**
        - El usuario crea nuevo contenido, como publicaciones de blog, artículos, videos o imágenes.
        - Edita contenido existente, realiza cambios, añade o elimina elementos.
        - Guarda o publica el contenido y comparte el enlace.
    
    ### ¿Qué es el hacking a aplicaciones Web?
    
    El hacking en aplicaciones web, también conocido como "hacking web" o "pentesting web", se refiere al proceso de identificar, explotar y remediar vulnerabilidades de seguridad en aplicaciones web y los sistemas subyacentes que las respaldan. Los hackers web buscan explotar debilidades en la lógica de programación, configuraciones incorrectas, fallos en la autenticación y autorización, entre otros, con el objetivo de comprometer la seguridad de la aplicación y, en última instancia, obtener acceso no autorizado o causar daño.
    
    ### Peligros del Hacking en aplicaciones Web
    
    En el hacking de aplicaciones web podemos encontrar varios peligros tanto para los usuarios como para las organizaciones que operan estas aplicaciones. Algunos de los peligros más comunes incluyen:
    
    1. **Robo de Datos Sensibles:** Los hackers pueden explotar vulnerabilidades en una aplicación web para acceder a datos confidenciales de los usuarios, como información de inicio de sesión, datos personales, detalles de tarjetas de crédito u otra información financiera.
    2. **Compromiso de la Seguridad de la Aplicación:** Los hackers pueden manipular o interrumpir el funcionamiento normal de una aplicación web mediante diversas técnicas, lo que puede resultar en la exposición de datos o la pérdida de control sobre la aplicación.
    3. **Riesgo de Fraude:** Si un hacker obtiene acceso no autorizado a una aplicación web, puede realizar actividades fraudulentas, como realizar transacciones no autorizadas, cambiar la información de la cuenta o realizar acciones maliciosas en nombre de los usuarios legítimos.
    4. **Daño a la Reputación:** Si se descubre que una aplicación web ha sido comprometida, puede dañar la reputación de la organización propietaria, lo que puede afectar la confianza de los usuarios y clientes en la seguridad de la aplicación y la marca en general.
    5. **Pérdida de Ingresos:** Un ataque exitoso contra una aplicación web puede resultar en la pérdida de ingresos directos, especialmente si los hackers pueden acceder y robar datos financieros de los usuarios, realizar transacciones fraudulentas o interrumpir la disponibilidad del servicio.