# Ejemplo

[Lab: File path traversal, simple case | Web Security Academy](https://portswigger.net/web-security/file-path-traversal/lab-simple)