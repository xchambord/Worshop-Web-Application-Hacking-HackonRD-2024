# Ejemplo

[Lab: 2FA simple bypass | Web Security Academy](https://portswigger.net/web-security/authentication/multi-factor/lab-2fa-simple-bypass)