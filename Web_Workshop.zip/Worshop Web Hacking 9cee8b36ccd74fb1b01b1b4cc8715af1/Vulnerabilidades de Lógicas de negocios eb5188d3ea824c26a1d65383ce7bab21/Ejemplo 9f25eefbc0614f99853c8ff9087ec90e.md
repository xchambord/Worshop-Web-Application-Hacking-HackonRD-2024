# Ejemplo

[Lab: Password reset broken logic | Web Security Academy](https://portswigger.net/web-security/authentication/other-mechanisms/lab-password-reset-broken-logic)