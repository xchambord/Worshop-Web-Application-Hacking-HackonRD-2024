# Vulnerabilidades en otros mecanismos de autenticación

Además de la funcionalidad básica de inicio de sesión, la mayoría de los sitios web ofrecen funciones complementarias para permitir a los usuarios administrar su cuenta. Por ejemplo, los usuarios normalmente pueden cambiar su contraseña o restablecerla cuando la olvidan. Estos mecanismos también pueden introducir vulnerabilidades que un atacante puede aprovechar.

Los sitios web suelen tener cuidado de evitar vulnerabilidades conocidas en sus páginas de inicio de sesión. Pero es fácil pasar por alto el hecho de que es necesario tomar medidas similares para garantizar que la funcionalidad relacionada sea igualmente sólida. Esto es especialmente importante en los casos en los que un atacante puede crear su propia cuenta y, en consecuencia, tiene fácil acceso para estudiar estas páginas adicionales.

## Mantener a los usuarios conectados

Una característica común es la opción de permanecer conectado incluso después de cerrar la sesión del navegador. Suele ser una casilla de verificación simple con la etiqueta "Recordarme" o "Mantenerme conectado".

Esta funcionalidad a menudo se implementa generando un token "recordarme" de algún tipo, que luego se almacena en una cookie persistente. Como poseer esta cookie de manera efectiva le permite omitir todo el proceso de inicio de sesión, es una buena práctica que no sea práctico adivinar esta cookie. Sin embargo, algunos sitios web generan esta cookie basándose en una concatenación predecible de valores estáticos, como el nombre de usuario y una marca de tiempo. Algunos incluso utilizan la contraseña como parte de la cookie. Este enfoque es particularmente peligroso si un atacante puede crear su propia cuenta porque puede estudiar su propia cookie y potencialmente deducir cómo se genera. Una vez que hayan resuelto la fórmula, pueden intentar forzar las cookies de otros usuarios por fuerza bruta para obtener acceso a sus cuentas.

Algunos sitios web asumen que si la cookie está cifrada de alguna manera, no será adivinable incluso si utiliza valores estáticos. Si bien esto puede ser cierto si se hace correctamente, "cifrar" ingenuamente la cookie utilizando una codificación bidireccional simple como Base64 no ofrece protección alguna. Incluso el uso de un cifrado adecuado con una función hash unidireccional no es completamente infalible. Si el atacante puede identificar fácilmente el algoritmo de hash y no se utiliza sal, puede potencialmente forzar la cookie con fuerza bruta simplemente aplicando hash en sus listas de palabras. Este método se puede utilizar para evitar los límites de intentos de inicio de sesión si no se aplica un límite similar a las suposiciones de cookies.

[Ejemplo](Vulnerabilidades%20en%20otros%20mecanismos%20de%20autenticac%202cc636ab728c445093cddd24fe6ff0e5/Ejemplo%202f7058660f24413faa11e3558d444cfe.md)

## Restablecer contraseñas de usuario

En la práctica, es un hecho que algunos usuarios olvidarán su contraseña, por lo que es común tener una forma de restablecerla. Como la autenticación habitual basada en contraseña es obviamente imposible en este escenario, los sitios web tienen que confiar en métodos alternativos para asegurarse de que el usuario real restablezca su propia contraseña. Por este motivo, la función de restablecimiento de contraseña es intrínsecamente peligrosa y debe implementarse de forma segura.

Hay algunas formas diferentes en que se implementa comúnmente esta característica, con distintos grados de vulnerabilidad.

### Envío de contraseñas por correo electrónico

No hace falta decir que enviar a los usuarios su contraseña actual nunca debería ser posible si un sitio web maneja las contraseñas de forma segura en primer lugar. En cambio, algunos sitios web generan una nueva contraseña y la envían al usuario por correo electrónico.

En términos generales, se debe evitar el envío de contraseñas persistentes a través de canales inseguros. En este caso, la seguridad depende de que la contraseña generada caduque después de un período muy corto o de que el usuario vuelva a cambiar su contraseña inmediatamente. De lo contrario, este enfoque es muy susceptible a ataques de intermediario.

Por lo general, el correo electrónico tampoco se considera seguro, dado que las bandejas de entrada son persistentes y no están realmente diseñadas para el almacenamiento seguro de información confidencial. Muchos usuarios también sincronizan automáticamente su bandeja de entrada entre múltiples dispositivos a través de canales inseguros.

### Restablecer contraseñas usando una URL

Un método más sólido para restablecer contraseñas es enviar una URL única a los usuarios que los lleve a una página de restablecimiento de contraseña. Las implementaciones menos seguras de este método utilizan una URL con un parámetro fácilmente adivinable para identificar qué cuenta se está restableciendo, por ejemplo:

```jsx
[http://vulnerable-website.com/reset-password?user=victim-user](http://vulnerable-website.com/reset-password?user=victim-user)
```

En este ejemplo, un atacante podría cambiar el parámetro de usuario para hacer referencia a cualquier nombre de usuario que haya identificado. Luego serán llevados directamente a una página donde potencialmente pueden establecer una nueva contraseña para este usuario arbitrario.

Una mejor implementación de este proceso es generar un token de alta entropía difícil de adivinar y crear la URL de reinicio en base a eso. En el mejor de los casos, esta URL no debería proporcionar pistas sobre qué contraseña de usuario se está restableciendo.

```jsx
[http://vulnerable-website.com/reset-password?token=a0ba0d1cb3b63d13822572fcff1a241895d893f659164d4cc550b421ebdd48a8](http://vulnerable-website.com/reset-password?token=a0ba0d1cb3b63d13822572fcff1a241895d893f659164d4cc550b421ebdd48a8)
```

Cuando el usuario visita esta URL, el sistema debe verificar si este token existe en el back-end y, de ser así, qué contraseña de usuario se supone que debe restablecer. Este token debería caducar después de un corto período de tiempo y destruirse inmediatamente después de que se haya restablecido la contraseña.

Sin embargo, algunos sitios web no vuelven a validar el token cuando se envía el formulario de restablecimiento. En este caso, un atacante podría simplemente visitar el formulario de restablecimiento desde su propia cuenta, eliminar el token y aprovechar esta página para restablecer la contraseña de un usuario arbitrario.

[Ejemplo](Vulnerabilidades%20en%20otros%20mecanismos%20de%20autenticac%202cc636ab728c445093cddd24fe6ff0e5/Ejemplo%20c92077a3db314dab8903b04856c43bff.md)