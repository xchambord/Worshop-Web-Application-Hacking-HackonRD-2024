# Vulnerabilidades de inicio de sesión basado en contraseña

Para los sitios web que adoptan un proceso de inicio de sesión basado en contraseña, los usuarios se registran ellos mismos para obtener una cuenta o un administrador les asigna una cuenta. Esta cuenta está asociada con un nombre de usuario único y una contraseña secreta, que el usuario ingresa en un formulario de inicio de sesión para autenticarse.

En este escenario, el mero hecho de conocer la contraseña secreta se considera prueba suficiente de la identidad del usuario. En consecuencia, la seguridad del sitio web se vería comprometida si un atacante pudiera obtener o adivinar las credenciales de inicio de sesión de otro usuario.

Esto se puede lograr de varias maneras, como exploraremos a continuación.

## Ataques de fuerza bruta

Un ataque de fuerza bruta se produce cuando un atacante utiliza un sistema de prueba y error para adivinar las credenciales de usuario válidas. Estos ataques suelen automatizarse mediante listas de palabras de nombres de usuario y contraseñas. Automatizar este proceso, especialmente utilizando herramientas dedicadas, potencialmente permite a un atacante realizar una gran cantidad de intentos de inicio de sesión a alta velocidad.

La fuerza bruta no siempre consiste simplemente en hacer conjeturas completamente aleatorias sobre nombres de usuarios y contraseñas. Al utilizar también lógica básica o conocimiento disponible públicamente, los atacantes pueden ajustar los ataques de fuerza bruta para hacer conjeturas mucho más fundamentadas. Esto aumenta considerablemente la eficacia de este tipo de ataques. Los sitios web que dependen del inicio de sesión basado en contraseña como único método para autenticar a los usuarios pueden ser muy vulnerables si no implementan suficiente protección de fuerza bruta.

### Ataques de fuerza bruta a nombres de usuarios

Los nombres de usuario son especialmente fáciles de adivinar si siguen un patrón reconocible, como una dirección de correo electrónico. Por ejemplo, es muy común ver inicios de sesión comerciales en el formato [nombre.apellido@algunaempresa.com](mailto:nombre.apellido@algunaempresa.com). Sin embargo, incluso si no existe un patrón obvio, a veces incluso las cuentas con altos privilegios se crean utilizando nombres de usuario predecibles, como admin o administrador.

Hay que verificar si el sitio web revela públicamente posibles nombres de usuario. Por ejemplo, ¿puedes acceder a los perfiles de usuario sin iniciar sesión? Incluso si el contenido real de los perfiles está oculto, el nombre utilizado en el perfil a veces es el mismo que el nombre de usuario de inicio de sesión. También debe verificar las respuestas HTTP para ver si se divulga alguna dirección de correo electrónico. En ocasiones, las respuestas contienen direcciones de correo electrónico de usuarios con muchos privilegios, como administradores o soporte de TI.

### Ataques de fuerza bruta a Contraseñas

De manera similar, las contraseñas pueden ser de fuerza bruta, y la dificultad varía según la seguridad de la contraseña. Muchos sitios web adoptan algún tipo de política de contraseñas, lo que obliga a los usuarios a crear contraseñas de alta entropía que son, al menos en teoría, más difíciles de descifrar utilizando únicamente la fuerza bruta. Por lo general, esto implica hacer cumplir las contraseñas con:

- Un número mínimo de caracteres.
- Una mezcla de letras minúsculas y mayúsculas.
- Al menos un carácter especial.

Sin embargo, si bien las contraseñas de alta entropía son difíciles de descifrar solo para las computadoras, podemos utilizar un conocimiento básico del comportamiento humano para explotar las vulnerabilidades que los usuarios introducen involuntariamente en este sistema. En lugar de crear una contraseña segura con una combinación aleatoria de caracteres, los usuarios a menudo toman una contraseña que pueden recordar e intentan manipularla para que se ajuste a la política de contraseñas. Por ejemplo, si mi contraseña no está permitida, los usuarios pueden probar algo como Mi contraseña1. o Myp4$$w0rd en su lugar.

En los casos en que la política requiere que los usuarios cambien sus contraseñas periódicamente, también es común que los usuarios simplemente realicen cambios menores y predecibles en su contraseña preferida. Por ejemplo, Mi contraseña1! se convierte en Micontraseña1? o Micontraseña2!.

Este conocimiento de las credenciales probables y los patrones predecibles significa que los ataques de fuerza bruta a menudo pueden ser mucho más sofisticados y, por lo tanto, efectivos, que simplemente iterar a través de cada combinación posible de personajes.