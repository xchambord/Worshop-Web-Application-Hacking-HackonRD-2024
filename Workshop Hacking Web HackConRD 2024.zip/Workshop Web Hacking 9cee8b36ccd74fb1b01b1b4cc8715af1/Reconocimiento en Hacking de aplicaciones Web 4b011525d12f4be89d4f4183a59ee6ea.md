# Reconocimiento en Hacking de aplicaciones Web

El reconocimiento en hacking de aplicaciones web, también conocido como "reconocimiento web", es la primera fase del proceso de prueba de penetración, en la cual el hacker recopila información sobre el objetivo de su ataque. Esta información es crucial para comprender la infraestructura de la aplicación, identificar posibles vulnerabilidades y planificar los siguientes pasos del ataque.

## Enumeraciones Comunes:

### Enumeración de Subdominios

La enumeración de subdominios es una técnica utilizada en hacking ético o pruebas de penetración para identificar todos los subdominios asociados con un dominio principal. Esta actividad es importante para comprender completamente la superficie de ataque de una organización y descubrir posibles puntos de entrada adicionales. 

La enumeración de subdominios tiene varios objetivos en el ámbito de la seguridad informática y el hacking ético. Algunos de los objetivos principales incluyen:

1. **Ampliar la Superficie de Ataque:** Al identificar todos los subdominios asociados con un dominio principal, se amplía la superficie de ataque potencial. Esto permite a los profesionales de seguridad y a los pentesters evaluar de manera más exhaustiva la seguridad de una organización o aplicación web.
2. **Descubrir Puntos de Entrada Adicionales:** Cada subdominio puede representar un posible punto de entrada para un atacante. Al enumerar estos subdominios, se identifican posibles vectores de ataque que podrían haber pasado desapercibidos de otra manera.
3. **Identificar Servicios y Tecnologías Utilizadas:** Los subdominios pueden indicar la presencia de servicios o tecnologías específicas utilizadas por una organización. Esto proporciona información valiosa para los profesionales de seguridad, ya que pueden investigar y evaluar las vulnerabilidades asociadas con estas tecnologías.
4. **Analizar la Arquitectura de la Aplicación:** La estructura de los subdominios puede ofrecer información sobre la arquitectura de la aplicación web de una organización, como la división de funciones o la separación de entornos de desarrollo, pruebas y producción. Esto puede ayudar a comprender mejor cómo están organizados los sistemas y dónde pueden existir vulnerabilidades.

[Ejemplos 1](Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea/Ejemplos%201%20c4bfcb53e8464c068d60c5ccbf05ad0d.md)

### Enumeración de Directorios

La enumeración de directorios es un proceso mediante el cual un atacante intenta descubrir y listar los directorios y archivos accesibles en un servidor web. Este es un paso común en la fase de reconocimiento de un ataque web, donde el objetivo es recopilar información sobre la estructura y contenido del sitio web para identificar posibles puntos de entrada, vulnerabilidades o información sensible.

Los objetivos principales de la enumeración de directorios en hacking de aplicaciones web son:

1. **Reconocimiento del sistema**: Obtener información sobre la estructura del sistema de archivos del servidor web, incluyendo directorios, archivos y permisos asociados.
2. **Identificación de puntos de entrada potenciales**: Descubrir áreas del sitio web que podrían ser vulnerables a ataques, como directorios con permisos de escritura o archivos con información sensible.
3. **Recolección de información sensible**: Encontrar archivos o directorios que contengan información confidencial o sensible, como archivos de configuración, archivos de registro, o incluso credenciales de usuario que podrían haber sido expuestas accidentalmente.
4. **Descubrimiento de recursos ocultos**: Identificar recursos que no están enlazados directamente desde el sitio web pero que aún son accesibles a través de la URL, lo que podría revelar funcionalidades ocultas o áreas no autorizadas.
5. **Preparación para ataques posteriores**: La enumeración de directorios puede proporcionar a un atacante una visión general del sitio web y sus posibles vulnerabilidades, lo que le permite planificar y ejecutar ataques más avanzados, como ataques de fuerza bruta, inyección de SQL o explotación de vulnerabilidades conocidas.

[Ejemplos 2](Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea/Ejemplos%202%202a4bdcae1334493bb6aa5fba7d6e9cc0.md)

### Enumerar IP detrás de WAF

Una de las formas más comunes de hacer Bypass al WAF implementado en la aplicación web es buscar la dirección IP real del Web Server. A continuación veremos un ejemplo detallado.

La implementación del WAF es similar a la de un proxy, donde la petición primero va al WAF y si está dentro de los parámetros establecidos es permitida al servidor web.

![Untitled](Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea/Untitled.png)

Para que un atacante le sea posible evadir los controles establecidos por el WAF, es necesario encontrar la IP del servidor web, esto se hace de diferentes formas:

[Ejemplos 3](Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea/Ejemplos%203%20bf57a976e56c4b30a621f6f54e0f73c0.md)

Luego de enumerar las posibles IPs del dominio, procedemos a hacer un Virtual Hosting con el dominio y las IPs enumeradas.

1. Notamos que el WAF nos esta bloqueando un simple payload de XSS (<script>alert(’XSS’)</script>).

![Untitled](Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea/Untitled%201.png)

![Untitled](Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea/Untitled%202.png)

1. Procedemos a acceder a nuestro archivo de configuración */etc/hosts* **(en linux)**, *C:\Windows\System32\Drivers\etc **(windows)** y /private/etc/hosts* **(Mac).**

![Untitled](Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea/Untitled%203.png)

1. Una vez hacemos el proceso de resolución de nombre local con la IP del servidor Web, se omiten los controles desplegados por el WAF, ya que el cliente hace una consulta directa con el servidor Web.

![Untitled](Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea/Untitled%204.png)

## Recomendaciones

La mejor solución para este tipo de omisión de WAF es incluir en la lista blanca las direcciones IP de su proveedor de WAF en el servidor web. No se debe poder acceder al servidor de origen desde ningún lugar excepto el WAF, lo que obliga a todos a utilizar la aplicación a través del WAF incluso si conocen la dirección IP del servidor de origen.

### Ejemplo de como incluir en la lista blanca las direcciones IP del WAF:

1. **Identificar las direcciones IP del proveedor WAF**: Comuníquese con su proveedor de WAF para obtener una lista de las direcciones IP que utilizan para enrutar el tráfico a través de su servicio.
2. **Acceder al servidor web**: Inicie sesión en el servidor web donde desea configurar la lista blanca. Esto puede requerir acceso a través de SSH u otro método de administración remota.
3. **Configurar la lista blanca en el servidor web**: Dependiendo del servidor web que esté utilizando (por ejemplo, Apache, Nginx, IIS), el proceso exacto para configurar la lista blanca puede variar. Aquí hay algunas opciones comunes:
    - Para Apache: Modifique su archivo de configuración de Apache (por lo general, **`httpd.conf`** o **`apache2.conf`**) para incluir directivas de acceso. Por ejemplo:
        
        ```bash
        
        <Directory /ruta/a/tu/aplicacion>
            Order Deny,Allow
            Deny from all
            Allow from IP_WAF_1 IP_WAF_2 ...
        </Directory>
        
        ```
        
    - Para Nginx: Modifique su archivo de configuración de Nginx (por lo general, **`nginx.conf`**) para incluir directivas de acceso. Por ejemplo:
        
        ```bash
        
        location / {
            allow IP_WAF_1;
            allow IP_WAF_2;
            deny all;
        }
        
        ```
        
    - Para IIS (Internet Information Services): Utilice el Editor de directivas de dirección IP en el Administrador de IIS para agregar las direcciones IP del WAF a la lista blanca.
4. **Reiniciar el servidor web**: Después de realizar cambios en la configuración del servidor web, asegúrese de reiniciar el servicio para que los cambios surtan efecto.
5. **Probar la configuración**: Verifique que la configuración de la lista blanca esté funcionando correctamente probando el acceso a su aplicación desde las direcciones IP del proveedor de WAF. También puede monitorear los registros de acceso del servidor web para asegurarse de que el tráfico de las direcciones IP especificadas esté siendo permitido correctamente.