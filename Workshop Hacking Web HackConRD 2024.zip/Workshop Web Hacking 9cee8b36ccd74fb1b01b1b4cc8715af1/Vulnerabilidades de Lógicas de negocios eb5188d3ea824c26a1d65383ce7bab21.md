# Vulnerabilidades de Lógicas de negocios

Las vulnerabilidades de la lógica empresarial son fallas en el diseño y la implementación de una aplicación que permiten a un atacante provocar un comportamiento no deseado. Esto potencialmente permite a los atacantes manipular funciones legítimas para lograr un objetivo malicioso. Estas fallas generalmente son el resultado de no anticipar estados inusuales de la aplicación que pueden ocurrir y, en consecuencia, no manejarlos de manera segura.

Los fallos lógicos suelen ser invisibles para las personas que no los buscan explícitamente, ya que normalmente no quedarán expuestos mediante el uso normal de la aplicación. Sin embargo, un atacante puede explotar peculiaridades de comportamiento interactuando con la aplicación de formas que los desarrolladores nunca pretendieron.

Uno de los principales propósitos de la lógica empresarial es hacer cumplir las reglas y restricciones que se definieron al diseñar la aplicación o funcionalidad. En términos generales, las reglas de negocio dictan cómo debe reaccionar la aplicación cuando ocurre un escenario determinado. Esto incluye evitar que los usuarios hagan cosas que tendrán un impacto negativo en el negocio o que simplemente no tienen sentido.

Los fallos en la lógica pueden permitir a los atacantes eludir estas reglas. Por ejemplo, es posible que puedan completar una transacción sin pasar por el flujo de trabajo de compra previsto. En otros casos, la validación rota o inexistente de los datos proporcionados por el usuario podría permitirles realizar cambios arbitrarios en valores críticos para transacciones o enviar información sin sentido. Al pasar valores inesperados a la lógica del lado del servidor, un atacante puede potencialmente inducir a la aplicación a hacer algo que no debería hacer.

Las vulnerabilidades basadas en lógica pueden ser extremadamente diversas y, a menudo, son exclusivas de la aplicación y su funcionalidad específica. Identificarlos a menudo requiere una cierta cantidad de conocimiento humano, como la comprensión del dominio empresarial o los objetivos que podría tener un atacante en un contexto determinado. Esto hace que sean difíciles de detectar mediante escáneres de vulnerabilidades automatizados. Como resultado, las fallas lógicas son un gran objetivo para los cazadores de recompensas y los evaluadores manuales en general.

Las vulnerabilidades de lógica de negocios son aquellas en las que un atacante explota el comportamiento del sistema o la aplicación en sí misma, en lugar de aprovechar fallas directas en el código o la infraestructura subyacente. Aquí tienes algunos ejemplos comunes de vulnerabilidades de lógica de negocios:

1. **Manipulación de parámetros en la URL**: Un usuario malintencionado puede modificar manualmente los parámetros de una URL para acceder a funcionalidades o recursos a los que no debería tener acceso. Por ejemplo, cambiando un parámetro de identificación de usuario en la URL para acceder a la información de otro usuario.
2. **Explotación de errores en la lógica del flujo de trabajo**: Pueden existir situaciones en las que el flujo de trabajo de una aplicación no esté correctamente diseñado o implementado, lo que permite a un atacante acceder a funcionalidades o datos no autorizados. Por ejemplo, un usuario podría omitir pasos importantes en un flujo de pago en línea y acceder a contenido premium sin pagar.
3. **Violación de políticas de negocio**: A veces, las aplicaciones no aplican correctamente las políticas de negocio establecidas, lo que permite a los usuarios realizar acciones que no están permitidas según las reglas del negocio. Por ejemplo, un usuario podría cambiar la cantidad de un artículo en su carrito de compras después de realizar el pago, lo que le permite comprar más productos de los que pagó originalmente.
4. **Manipulación de secuencias de solicitud y respuesta**: Un atacante puede manipular el orden o la secuencia de las solicitudes y respuestas de una aplicación para obtener acceso no autorizado a recursos o funcionalidades. Por ejemplo, cambiando el orden de las solicitudes en una aplicación de comercio electrónico para realizar compras sin pagar.
5. **Explotación de limitaciones de tiempo**: Algunas aplicaciones pueden tener limitaciones de tiempo en ciertas funcionalidades o procesos, como el inicio de sesión o la confirmación de una transacción. Los atacantes pueden intentar explotar estas limitaciones para acceder a recursos o realizar acciones después de que hayan expirado los plazos previstos.
6. **Redireccionamiento no válido**: Las aplicaciones a menudo tienen funciones de redireccionamiento para enviar a los usuarios a otras páginas o sitios web. Si estas redirecciones no se validan correctamente, un atacante podría utilizarlas para engañar a los usuarios y dirigirlos a sitios maliciosos.

## ¿Cómo surgen las vulnerabilidades de la lógica empresarial?

Las vulnerabilidades de la lógica empresarial a menudo surgen porque los equipos de diseño y desarrollo hacen suposiciones erróneas sobre cómo interactuarán los usuarios con la aplicación. Estas malas suposiciones pueden conducir a una validación inadecuada de las aportaciones del usuario. Por ejemplo, si los desarrolladores suponen que los usuarios pasarán datos exclusivamente a través de un navegador web, la aplicación puede depender completamente de controles débiles del lado del cliente para validar la entrada. Un atacante puede evitarlos fácilmente mediante un proxy de interceptación.

En última instancia, esto significa que cuando un atacante se desvía del comportamiento esperado del usuario, la aplicación no toma las medidas adecuadas para evitarlo y, posteriormente, no logra manejar la situación de manera segura.

Los fallos lógicos son particularmente comunes en sistemas demasiado complicados que ni siquiera el propio equipo de desarrollo comprende del todo. Para evitar fallas lógicas, los desarrolladores deben comprender la aplicación en su conjunto. Esto incluye ser consciente de cómo se pueden combinar diferentes funciones de formas inesperadas. Es posible que los desarrolladores que trabajan en bases de código grandes no tengan un conocimiento profundo de cómo funcionan todas las áreas de la aplicación. Alguien que trabaje en un componente podría hacer suposiciones erróneas sobre cómo funciona otro componente y, como resultado, introducir sin darse cuenta graves fallos lógicos. Si los desarrolladores no documentan explícitamente ninguna de las suposiciones que se están haciendo, es fácil que este tipo de vulnerabilidades se introduzcan en una aplicación.

## ¿Cuál es el impacto de las vulnerabilidades de la lógica empresarial?

El impacto de las vulnerabilidades de la lógica empresarial puede, en ocasiones, ser bastante trivial. Es una categoría amplia y el impacto es muy variable. Sin embargo, cualquier comportamiento no intencionado puede provocar ataques de alta gravedad si un atacante puede manipular la aplicación de la manera correcta. Por esta razón, lo ideal es solucionar la lógica peculiar incluso si no puedes descubrir cómo explotarla por ti mismo. Siempre existe el riesgo de que alguien más pueda hacerlo.

Fundamentalmente, el impacto de cualquier falla lógica depende de con qué funcionalidad está relacionada. Si la falla está en el mecanismo de autenticación, por ejemplo, esto podría tener un impacto grave en su seguridad general. Los atacantes podrían aprovechar esto para escalar privilegios o para eludir la autenticación por completo, obteniendo acceso a datos y funciones confidenciales. Esto también expone una mayor superficie de ataque para otros exploits.

Obviamente, una lógica defectuosa en las transacciones financieras puede provocar pérdidas masivas para la empresa debido al robo de fondos, el fraude, etc.

También debe tener en cuenta que, aunque las fallas lógicas no permitan que un atacante se beneficie directamente, aún podrían permitir que una parte malintencionada dañe el negocio de alguna manera.

## ¿Cuáles son algunos ejemplos de vulnerabilidades de la lógica empresarial?

La mejor manera de comprender las vulnerabilidades de la lógica empresarial es observar casos del mundo real y aprender de los errores cometidos. Hemos proporcionado ejemplos concretos de una variedad de fallas lógicas comunes, así como algunos sitios web deliberadamente vulnerables para que usted mismo pueda practicar cómo explotar estas vulnerabilidades.

### Confianza excesiva en los controles del lado del cliente

Una suposición fundamentalmente errónea es que los usuarios sólo interactuarán con la aplicación a través de la interfaz web proporcionada. Esto es especialmente peligroso porque lleva a la suposición adicional de que la validación del lado del cliente evitará que los usuarios proporcionen datos maliciosos. Sin embargo, un atacante puede simplemente usar herramientas como Burp Proxy para alterar los datos después de que hayan sido enviados por el navegador pero antes de que pasen a la lógica del lado del servidor. Esto efectivamente inutiliza los controles del lado del cliente.

Aceptar datos al pie de la letra, sin realizar comprobaciones de integridad adecuadas y validación del lado del servidor, puede permitir que un atacante cause todo tipo de daños con un esfuerzo relativamente mínimo. Exactamente lo que pueden lograr depende de la funcionalidad y de lo que esté haciendo con los datos controlables. En el contexto adecuado, este tipo de falla puede tener consecuencias devastadoras tanto para la funcionalidad relacionada con el negocio como para la seguridad del sitio web en sí.

[Ejemplo](Vulnerabilidades%20de%20Lo%CC%81gicas%20de%20negocios%20eb5188d3ea824c26a1d65383ce7bab21/Ejemplo%20a7de8b944b2543188e40f091c1677822.md)

### Los usuarios no siempre proporcionarán información obligatoria

Una idea errónea es que los usuarios siempre proporcionarán valores para los campos de entrada obligatorios. Los navegadores pueden impedir que los usuarios comunes envíen un formulario sin una entrada requerida, pero como sabemos, los atacantes pueden alterar los parámetros en tránsito. Esto incluso se extiende a la eliminación completa de parámetros.

Este es un problema particular en los casos en los que se implementan múltiples funciones dentro del mismo script del lado del servidor. En este caso, la presencia o ausencia de un parámetro particular puede determinar qué código se ejecuta. Eliminar los valores de los parámetros puede permitir que un atacante acceda a rutas de código que se supone que están fuera de su alcance.

Al buscar fallas lógicas, debe intentar eliminar cada parámetro por turno y observar qué efecto tiene esto en la respuesta. Debes asegurarte de:

- Elimine solo un parámetro a la vez para garantizar que se alcancen todas las rutas de código relevantes.
- Intente eliminar el nombre del parámetro y el valor. El servidor normalmente manejará ambos casos de manera diferente.
- Siga procesos de varias etapas hasta su finalización. A veces, la manipulación de un parámetro en un paso tendrá un efecto en otro paso más adelante en el flujo de trabajo.

Esto se aplica tanto a los parámetros de URL como a los de POST, pero no olvides comprobar también las cookies. Este sencillo proceso puede revelar algún comportamiento extraño de la aplicación que puede ser explotable.

[Ejemplo](Vulnerabilidades%20de%20Lo%CC%81gicas%20de%20negocios%20eb5188d3ea824c26a1d65383ce7bab21/Ejemplo%209f25eefbc0614f99853c8ff9087ec90e.md)

### Los usuarios no siempre seguirán la secuencia prevista

Muchas transacciones dependen de flujos de trabajo predefinidos que constan de una secuencia de pasos. La interfaz web normalmente guiará a los usuarios a través de este proceso, llevándolos al siguiente paso del flujo de trabajo cada vez que completen el actual. Sin embargo, los atacantes no necesariamente seguirán esta secuencia prevista. No tener en cuenta esta posibilidad puede generar fallas peligrosas que pueden ser relativamente fáciles de explotar.

Por ejemplo, muchos sitios web que implementan la autenticación de dos factores (2FA) requieren que los usuarios inicien sesión en una página antes de ingresar un código de verificación en una página separada. Suponer que los usuarios siempre seguirán este proceso hasta su finalización y, como resultado, no verificar que lo hagan, puede permitir a los atacantes omitir el paso 2FA por completo.

[Ejemplo](Vulnerabilidades%20de%20Lo%CC%81gicas%20de%20negocios%20eb5188d3ea824c26a1d65383ce7bab21/Ejemplo%20ae7f6d9a3fc4466c9647d240294eedf3.md)

# Cómo prevenir vulnerabilidades en la lógica empresarial

En resumen, las claves para prevenir vulnerabilidades en la lógica de negocios son:

- Asegúrese de que los desarrolladores y evaluadores comprendan el dominio al que sirve la aplicación.
- Evite hacer suposiciones implícitas sobre el comportamiento del usuario o el comportamiento de otras partes de la aplicación.

Debe identificar qué suposiciones ha hecho sobre el estado del lado del servidor e implementar la lógica necesaria para verificar que se cumplan estas suposiciones. Esto incluye asegurarse de que el valor de cualquier entrada sea razonable antes de continuar.

También es importante asegurarse de que tanto los desarrolladores como los evaluadores puedan comprender completamente estas suposiciones y cómo se supone que debe reaccionar la aplicación en diferentes escenarios. Esto puede ayudar al equipo a detectar fallas lógicas lo antes posible. Para facilitar esto, el equipo de desarrollo debe cumplir con las siguientes mejores prácticas siempre que sea posible:

- Mantenga documentos de diseño y flujos de datos claros para todas las transacciones y flujos de trabajo, anotando cualquier suposición que se haga en cada etapa.
- Escriba el código lo más claramente posible. Si es difícil entender lo que se supone que debe suceder, será difícil detectar fallas lógicas. Idealmente, un código bien escrito no debería necesitar documentación para comprenderlo. En casos inevitablemente complejos, producir documentación clara es crucial para garantizar que otros desarrolladores y evaluadores sepan qué suposiciones se están haciendo y exactamente cuál es el comportamiento esperado.
- Tenga en cuenta cualquier referencia a otro código que utilice cada componente. Piense en los efectos secundarios de estas dependencias si una parte malintencionada las manipulara de una manera inusual.

Debido a la naturaleza relativamente única de muchos fallos lógicos, es fácil descartarlos como un error único debido a un error humano y seguir adelante. Sin embargo, como hemos demostrado, estos fallos suelen ser el resultado de malas prácticas en las fases iniciales de creación de la aplicación. Analizar por qué existía una falla lógica en primer lugar y cómo el equipo la pasó por alto puede ayudarlo a detectar debilidades en sus procesos. Al realizar ajustes menores, puede aumentar la probabilidad de que fallas similares se eliminen en el origen o se detecten antes en el proceso de desarrollo.