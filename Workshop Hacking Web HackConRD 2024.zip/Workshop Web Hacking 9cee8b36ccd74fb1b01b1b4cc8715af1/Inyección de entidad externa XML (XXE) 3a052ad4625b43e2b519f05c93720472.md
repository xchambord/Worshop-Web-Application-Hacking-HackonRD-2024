# Inyección de entidad externa XML (XXE)

## ¿Qué es XML?

XML significa "lenguaje de marcado extensible". XML es un lenguaje diseñado para almacenar y transportar datos. Al igual que HTML, XML utiliza una estructura de etiquetas y datos en forma de árbol. A diferencia de HTML, XML no utiliza etiquetas predefinidas, por lo que a las etiquetas se les pueden dar nombres que describan los datos. Al principio de la historia de la web, XML estaba de moda como formato de transporte de datos (la "X" en "AJAX" significa "XML"). Pero su popularidad ha disminuido en favor del formato JSON.

## ¿Qué son las entidades XML?

Las entidades XML son una forma de representar un elemento de datos dentro de un documento XML, en lugar de utilizar los datos en sí. Varias entidades están integradas en la especificación del lenguaje XML. Por ejemplo, las entidades < y > representan los caracteres < y >. Estos son metacaracteres que se utilizan para indicar etiquetas XML y, por lo tanto, generalmente deben representarse utilizando sus entidades cuando aparecen dentro de los datos.

## ¿Qué es la definición de tipo de documento?

La definición de tipo de documento XML (DTD) contiene declaraciones que pueden definir la estructura de un documento XML, los tipos de valores de datos que puede contener y otros elementos. La DTD se declara dentro del elemento DOCTYPE opcional al comienzo del documento XML. La DTD puede ser totalmente autónoma dentro del propio documento (conocida como "DTD interna") o puede cargarse desde otro lugar (conocida como "DTD externa") o puede ser una combinación de ambas.

## ¿Qué son las entidades personalizadas XML?

XML permite definir entidades personalizadas dentro de la DTD. Por ejemplo:

```xml
<!DOCTYPE foo [ <!ENTITY myentity "my entity value" > ]>
```

Esta definición significa que cualquier uso de la referencia de entidad *&myentity;* dentro del documento XML se reemplazará con el valor definido: "*mi valor de entidad*".

## ¿Qué son las entidades externas XML?

Las entidades externas XML son un tipo de entidad personalizada cuya definición se encuentra fuera de la DTD donde se declaran.

La declaración de una entidad externa utiliza la palabra clave SISTEMA y debe especificar una URL desde la cual se debe cargar el valor de la entidad. Por ejemplo:

```xml
<!DOCTYPE foo [ <!ENTITY ext SYSTEM "[http://normal-website.com](http://normal-website.com/)" > ]>
```

La URL puede utilizar el protocolo *file://* y, por lo tanto, se pueden cargar entidades externas desde el archivo. Por ejemplo:

```xml
<!DOCTYPE foo [ <!ENTITY ext SYSTEM "file:///path/to/file" > ]>

```

Las entidades externas XML proporcionan el medio principal por el cual surgen los ataques de entidades externas XML.

# ¿Qué es la inyección de entidad externa XML?

La inyección de entidad externa XML (también conocida como XXE) es una vulnerabilidad de seguridad web que permite a un atacante interferir con el procesamiento de datos XML de una aplicación. A menudo permite a un atacante ver archivos en el sistema de archivos del servidor de aplicaciones e interactuar con cualquier sistema back-end o externo al que la propia aplicación pueda acceder.

En algunas situaciones, un atacante puede intensificar un ataque XXE para comprometer el servidor subyacente u otra infraestructura de back-end, aprovechando la vulnerabilidad XXE para realizar ataques de falsificación de solicitudes del lado del servidor (SSRF).

## ¿Cómo surgen las vulnerabilidades XXE?

Algunas aplicaciones utilizan el formato XML para transmitir datos entre el navegador y el servidor. Las aplicaciones que hacen esto prácticamente siempre utilizan una biblioteca estándar o una plataforma API para procesar los datos XML en el servidor. Las vulnerabilidades XXE surgen porque la especificación XML contiene varias características potencialmente peligrosas y los analizadores estándar admiten estas características incluso si la aplicación no las utiliza normalmente.

Las entidades externas XML son un tipo de entidad XML personalizada cuyos valores definidos se cargan desde fuera de la DTD en la que se declaran. Las entidades externas son particularmente interesantes desde una perspectiva de seguridad porque permiten definir una entidad en función del contenido de una ruta de archivo o URL.

## Explotando XXE para recuperar archivos

Para realizar un ataque de inyección XXE que recupere un archivo arbitrario del sistema de archivos del servidor, debe modificar el XML enviado de dos maneras:

- Introduzca (o edite) un elemento *DOCTYPE* que defina una entidad externa que contenga la ruta al archivo.
- Edite un valor de datos en el XML que se devuelve en la respuesta de la aplicación, para hacer uso de la entidad externa definida.

Por ejemplo, supongamos que una aplicación de compras verifica el nivel de existencias de un producto enviando el siguiente XML al servidor:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<stockCheck><productId>381</productId></stockCheck>
```

Esta carga útil XXE define una entidad externa *&xxe;* cuyo valor es el contenido del archivo */etc/passwd* y utiliza la entidad dentro del valor *productId*. Esto hace que la respuesta de la aplicación incluya el contenido del archivo:

```xml
Invalid product ID: root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
bin:x:2:2:bin:/bin:/usr/sbin/nologin
...
```

[Ejemplo](Inyeccio%CC%81n%20de%20entidad%20externa%20XML%20(XXE)%203a052ad4625b43e2b519f05c93720472/Ejemplo%2078b7d4435d8447a38c3763a34bfd791b.md)

# Cómo prevenir las vulnerabilidades XXE

Prácticamente todas las vulnerabilidades de XXE surgen porque la biblioteca de análisis XML de la aplicación admite funciones XML potencialmente peligrosas que la aplicación no necesita ni pretende utilizar. La forma más sencilla y eficaz de prevenir ataques XXE es desactivar esas funciones.

Generalmente, es suficiente deshabilitar la resolución de entidades externas y deshabilitar la compatibilidad con XInclude. Por lo general, esto se puede hacer mediante opciones de configuración o anulando mediante programación el comportamiento predeterminado. Consulte la documentación de su biblioteca de análisis XML o API para obtener detalles sobre cómo deshabilitar capacidades innecesarias.