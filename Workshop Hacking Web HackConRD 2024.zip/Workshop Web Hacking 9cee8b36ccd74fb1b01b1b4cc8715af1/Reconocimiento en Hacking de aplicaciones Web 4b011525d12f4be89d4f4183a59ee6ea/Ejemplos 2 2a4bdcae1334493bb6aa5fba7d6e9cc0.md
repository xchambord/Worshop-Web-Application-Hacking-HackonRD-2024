# Ejemplos 2

1. Activamos nuestro BurpSuite y damos clic en “Open browser”

![Untitled](Ejemplos%202%202a4bdcae1334493bb6aa5fba7d6e9cc0/Untitled.png)

1. Una vez en el navegador, buscamos la pagina a la cual le haremos la enumeracion de directorio.

![Untitled](Ejemplos%202%202a4bdcae1334493bb6aa5fba7d6e9cc0/Untitled%201.png)

1. Luego nos dirigimos al “HTTP History” donde podremos ver todas las peticiones.

![Untitled](Ejemplos%202%202a4bdcae1334493bb6aa5fba7d6e9cc0/Untitled%202.png)

1. Una vez en “HTTP History” damos clic derecho sobre la petición que queremos enviar al “Intruder”.

![Untitled](Ejemplos%202%202a4bdcae1334493bb6aa5fba7d6e9cc0/Untitled%203.png)

1. Cuando estemos en el “intruder”  escribimos una palabra random y la sombrearemos para posteriormente presionar el boton “Add $”.

![Untitled](Ejemplos%202%202a4bdcae1334493bb6aa5fba7d6e9cc0/Untitled%204.png)

1. Una vez en la pestaña de “Payloads” procederemos a pegar nuestra lista de nombre de directorios (Extraida del enlace anexado) y por ultimo damos clic en “Start attack”.

[](https://github.com/danielmiessler/SecLists/blob/master/Discovery/Web-Content/directory-list-2.3-medium.txt)

![Untitled](Ejemplos%202%202a4bdcae1334493bb6aa5fba7d6e9cc0/Untitled%205.png)

1. Por ultimo, verificaremos los directorios enumerados exitosamente.

![Untitled](Ejemplos%202%202a4bdcae1334493bb6aa5fba7d6e9cc0/Untitled%206.png)

## Existen otros tipos de herramientas para la enumeración de directorios.

### Dirbuster

DirBuster es una herramienta de código abierto diseñada para descubrir directorios ocultos y archivos en un servidor web mediante ataques de fuerza bruta o diccionario. Fue desarrollada por la organización OWASP (Open Web Application Security Project) como una herramienta de prueba de penetración para identificar posibles vulnerabilidades de seguridad en aplicaciones web.

[https://www.kali.org/tools/dirbuster/](https://www.kali.org/tools/dirbuster/)

### **dirsearch**

Dirsearch es una herramienta de código abierto utilizada para buscar y descubrir directorios y archivos ocultos en servidores web mediante ataques de fuerza bruta o diccionario. Fue desarrollada en Python y es altamente personalizable y fácil de usar.

[https://www.kali.org/tools/dirsearch/](https://www.kali.org/tools/dirsearch/)