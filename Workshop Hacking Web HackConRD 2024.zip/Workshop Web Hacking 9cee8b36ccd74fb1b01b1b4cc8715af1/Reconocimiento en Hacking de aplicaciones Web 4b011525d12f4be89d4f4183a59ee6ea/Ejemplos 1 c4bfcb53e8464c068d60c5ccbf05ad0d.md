# Ejemplos 1

Aqui veremos algunos ejemplos de como enumerar Subdominios relacionados a un sitio web:

## 1. Busqueda de Subdomios Mediante la herramienta en linea “DNSdumpster”

[DNSdumpster.com - dns recon and research, find and lookup dns records](https://dnsdumpster.com/)

1. Introducimos el dominio principal en el apartado de busqueda.

![Untitled](Ejemplos%201%20c4bfcb53e8464c068d60c5ccbf05ad0d/Untitled.png)

1. Una vez completada la busqueda, nos apareceran los resultados de los subdomios encontrados.

![Untitled](Ejemplos%201%20c4bfcb53e8464c068d60c5ccbf05ad0d/Untitled%201.png)

## 2. Busqueda de Subdomios Mediante los Google Dorks.

1. Para este ejemplo utilizaremos el filtro “Site:” seguido de un “*”, un punto y el dominio principal, indicandole a google mostrar todos los subdomios indexados en internet. 

![Untitled](Ejemplos%201%20c4bfcb53e8464c068d60c5ccbf05ad0d/Untitled%202.png)

## 3. Busqueda de Subdomios Mediante la herramienta en linea “Netcraft”

[Tools | Netcraft](https://www.netcraft.com/tools/)

1. Nos dirigimos a la pagina de netcraft en la opcion de buscar DNS.

![Untitled](Ejemplos%201%20c4bfcb53e8464c068d60c5ccbf05ad0d/Untitled%203.png)

1. Colocamos el dominio al cualqueremos analizar.

![Untitled](Ejemplos%201%20c4bfcb53e8464c068d60c5ccbf05ad0d/Untitled%204.png)

1. Una vez terminado el analisis nos mostrara los subdomios encontrados.

![Untitled](Ejemplos%201%20c4bfcb53e8464c068d60c5ccbf05ad0d/Untitled%205.png)