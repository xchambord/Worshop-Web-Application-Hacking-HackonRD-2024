# Laboratorios

[https://github.com/xchambord/Worshop-Web-Application-Hacking-HackonRD-2024/blob/main/LABORATORIOS HACKING WEB HACKONRD2024.pdf](https://github.com/xchambord/Worshop-Web-Application-Hacking-HackonRD-2024/blob/main/LABORATORIOS%20HACKING%20WEB%20HACKONRD2024.pdf)

### Hacking en autenticación Web (Login)

Lab 1 Vulnerabilidades de inicio de sesión basado en contraseña
[https://portswigger.net/web-security/authentication/password-based/lab-username-enumeration-via-different-responses](https://portswigger.net/web-security/authentication/password-based/lab-username-enumeration-via-different-responses)

Lab 2 Vulnerabilidades de autenticación multifactor
[https://portswigger.net/web-security/authentication/multi-factor/lab-2fa-simple-bypass](https://portswigger.net/web-security/authentication/multi-factor/lab-2fa-simple-bypass)

Lab 3 Vulnerabilidades en otros mecanismos de autenticación
[https://portswigger.net/web-security/authentication/other-mechanisms/lab-brute-forcing-a-stay-logged-in-cookie](https://portswigger.net/web-security/authentication/other-mechanisms/lab-brute-forcing-a-stay-logged-in-cookie)

### Vulnerabilidad de Control de Acceso

Lab 4 Funcionalidad administrador desprotegido

[https://portswigger.net/web-security/access-control/lab-unprotected-admin-functionality](https://portswigger.net/web-security/access-control/lab-unprotected-admin-functionality) 

Lab 5 Rol de usuario controlado por parámetro de solicitud

[https://portswigger.net/web-security/access-control/lab-user-role-controlled-by-request-parameter](https://portswigger.net/web-security/access-control/lab-user-role-controlled-by-request-parameter)

### Vulnerabilidades de Lógicas de negocios

Lab 6 Fallas lógicas confianza excesiva en los controles del lado del cliente

[https://portswigger.net/web-security/logic-flaws/examples/lab-logic-flaws-excessive-trust-in-client-side-controls](https://portswigger.net/web-security/logic-flaws/examples/lab-logic-flaws-excessive-trust-in-client-side-controls)

Lab 7 Lógica restablecimiento contraseña rota

[https://portswigger.net/web-security/authentication/other-mechanisms/lab-password-reset-broken-logic](https://portswigger.net/web-security/authentication/other-mechanisms/lab-password-reset-broken-logic)

### Vulnerabilidad en la carga de Archivo

Lab 8 Carga de archivos ejecución remota de código a traves de carga web shell
[https://portswigger.net/web-security/file-upload/lab-file-upload-remote-code-execution-via-web-shell-upload](https://portswigger.net/web-security/file-upload/lab-file-upload-remote-code-execution-via-web-shell-upload)

Lab 9 Carga de archivos web shell carga mediante extensión de archivo ofuscada

[https://portswigger.net/web-security/file-upload/lab-file-upload-web-shell-upload-via-obfuscated-file-extension](https://portswigger.net/web-security/file-upload/lab-file-upload-web-shell-upload-via-obfuscated-file-extension)

### Vulnerabilidades de Directorio Transversal

Lab 10 Path Traversal
[https://portswigger.net/web-security/file-path-traversal/lab-simple](https://portswigger.net/web-security/file-path-traversal/lab-simple)

 Lab 11 Evitación de ruta absoluta de laboratorio

[https://portswigger.net/web-security/file-path-traversal/lab-absolute-path-bypass](https://portswigger.net/web-security/file-path-traversal/lab-absolute-path-bypass)

### Inyección de entidad externa XML (XXE)

Lab 12 Explotando xxe para recuperar archivos
[https://portswigger.net/web-security/xxe/lab-exploiting-xxe-to-retrieve-files](https://portswigger.net/web-security/xxe/lab-exploiting-xxe-to-retrieve-files)