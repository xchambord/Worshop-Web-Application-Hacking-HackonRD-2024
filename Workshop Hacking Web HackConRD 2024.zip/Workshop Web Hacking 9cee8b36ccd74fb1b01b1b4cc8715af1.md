# Workshop Web Hacking

[Presentacion](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Presentacion%2084742e751dec4f7a9d0693e573e578b7.md)

[Agenda](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Agenda%20d59145664c2c4456a01203d60b4e9434.md)

[
Fundamentos Generales de Hacking a aplicaciones Web](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Fundamentos%20Generales%20de%20Hacking%20a%20aplicaciones%20We%2037a194c831184763bea9c4e5a7f75943.md)

[Reconocimiento en Hacking de aplicaciones Web](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Reconocimiento%20en%20Hacking%20de%20aplicaciones%20Web%204b011525d12f4be89d4f4183a59ee6ea.md)

[Hacking en autenticación Web (Login)](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Hacking%20en%20autenticacio%CC%81n%20Web%20(Login)%20aa59dd50e2a9447a94e29707d63444e2.md)

[Vulnerabilidad de Control de Acceso](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Vulnerabilidad%20de%20Control%20de%20Acceso%2056e8b1848bff47da9dd7870cfec73b5b.md)

[Vulnerabilidades de Lógicas de negocios](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Vulnerabilidades%20de%20Lo%CC%81gicas%20de%20negocios%20eb5188d3ea824c26a1d65383ce7bab21.md)

[
Vulnerabilidad en la carga de Archivo](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Vulnerabilidad%20en%20la%20carga%20de%20Archivo%20f6568ae2914a4698bfa732f89cf5ed50.md)

[Vulnerabilidades de Directorio Transversal](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Vulnerabilidades%20de%20Directorio%20Transversal%20ba604d43e3b3415ca956e7842088a931.md)

[Inyección de entidad externa XML (XXE)](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Inyeccio%CC%81n%20de%20entidad%20externa%20XML%20(XXE)%203a052ad4625b43e2b519f05c93720472.md)

[Laboratorios](Workshop%20Web%20Hacking%209cee8b36ccd74fb1b01b1b4cc8715af1/Laboratorios%20aceac2477f364d82ad577e4bb228f7bc.md)